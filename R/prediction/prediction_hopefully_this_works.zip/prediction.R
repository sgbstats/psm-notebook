library(tidyverse)

library(MASS)
library(Hmisc)
library(lme4)
library(mi)
library(doSNOW)
library(pROC)
`%notin%`=Negate(`%in%`)

# out=submodels(DATA %>% filter(train), model, MASS::glm.nb, contrasts=NULL)
submodels<- function(DATA, model, model_fn,submodel_type=c("pmks", "ccsm"), force_variables=c(),remove_model_data=c("model", "y", "fitted"), ...){
  #DATA=the training data
  #model = the model as a string
  #model_fn= the function for the model being used
  #force_varaibles = Any variables that you want to force into the model
  # remove_subject_data is to remve the ipd from the model
  submodel_type=match.arg(submodel_type)
  
  mod.DATA<- get_all_vars(as.formula(model), data=DATA) %>% drop_na(,1) %>% drop_na(all_of(force_variables))
  
  SDATA<- mod.DATA[,-1] #remove the outcome 
  var_names=names(SDATA)
  unpack(missingness_pattern(SDATA))
  # tmp.dat      <- as.data.frame(is.na(SDATA)*1)
  # tmp.pattern  <- factor(apply(tmp.dat,1,function(z) paste(z,collapse="")))
  # 
  # 
  # tmp.info     <- split(seq(nrow(SDATA)), tmp.pattern)
  # mp.levels    <- levels(tmp.pattern)
  # mp.pattern   <- do.call(rbind, lapply(as.list(mp.levels),function(ZZ) strsplit(ZZ,'')[[1]])) 		
  # mp.info     <- data.frame(cbind(names(tmp.info), unlist(lapply(tmp.info, length))),
  #                           stringsAsFactors= FALSE)
  # rownames(mp.info) <- seq(nrow(mp.info))
  # colnames(mp.info) <- c('mp','n')
  
  all.patterns0=expand.grid(rep(list(0:1),ncol(SDATA)))
  names(all.patterns0)=var_names
  #stops the computing of models that would have dropped the force variables.
  remove=intersect(var_names, force_variables)
  all.patterns1=all.patterns0[rowSums(as.matrix(all.patterns0[,remove]==1))==0,]
  all.patterns <- factor(apply(all.patterns1,1,function(z) paste(z,collapse="")))
  obs.patterns <- unique(tmp.pattern)
  
  
  if(length(setdiff(all.patterns,obs.patterns)) == 0){
    empty.patterns = NULL
  } else {
    empty.patterns <- data.frame(mp = factor(setdiff(all.patterns,obs.patterns)), n=0)
  }	
  mp.info <- rbind(mp.info,empty.patterns)
  
  
  unpack(model_breakdown(model))
  
  
  cc <- ncol(model.matrix(as.formula(model),mod.DATA))
  
  threshold <- cc*2
  mp.info$use.ptmx <- (as.numeric(mp.info$n)>=threshold)*1
  
  reg.out <- vector('list', length(all.patterns))
  names(reg.out) <- mp.info$mp.info
  
  
  for(ixx in seq(nrow(mp.info))) {
    col.keep  <- which(strsplit(mp.info$mp[ixx],'')[[1]]=='0')
    if(length(col.keep)==0){
      new.mod <- paste(mod.lhs,1,sep='~')
    } else {
      new.mod   <- paste(mod.lhs,paste(mod.rhs[col.keep],collapse='+'),
                         sep='~')
    }
    #adding in the interaction term
    if(length(mod.rhs.interaction>0)){
      for(i in 1:length(mod.rhs.interaction))
        new.mod=gsub(gsub("\\*","\\\\+",mod.rhs.interaction[i]), mod.rhs.interaction[i], new.mod)
    }
    new.mod=as.formula(new.mod)
    
    # print(class(DATA$eos_bl))
    if(mp.info$use.ptmx[ixx]==1&submodel_type=="pkms"){
      
      reg.out[[ixx]] <- list(pattern = mod.rhs[col.keep],
                             mod = model_fn(formula=new.mod,data=mod.DATA[tmp.info[[ixx]],]))
    }else{
      
      reg.out[[ixx]] <- list(pattern = mod.rhs[col.keep],
                             mod	 = model_fn(formula=new.mod,data=mod.DATA))
      
    }
    # if(remove_subject_data){
    #   reg.out[[ixx]][["mod"]][["model"]]=NULL
    #   # coefs=reg.out[[ixx]][["mod"]][["coefficients"]]
    #   # reg.out[[ixx]][["mod"]]=NULL
    #   # reg.out[[ixx]][["mod"]][["coefficients"]]=coefs
    #   }
    
    for(i in remove_model_data){
      reg.out[[ixx]][["mod"]][[i]]=NULL
    }
  }
  reg.out[["meta"]][["model"]]=model
  reg.out[["meta"]][["vars"]]=var_names
  reg.out[["meta"]][["force_variables"]]=force_variables
  reg.out[["meta"]][["mp.info"]]=mp.info
  reg.out[["meta"]][["all.patterns"]]=all.patterns
  reg.out[["meta"]][["submodel_type"]]=submodel_type
  
  return(reg.out)
}


predict.submodels <- function(prediction.data, submodels.object,se.fit=T,retain_lhs=F, ...){
  
  unpack(model_breakdown(submodels.object[["meta"]][["model"]]))
  
  
  mod.DATA<-prediction.data %>% dplyr::select(any_of(c(mod.lhs, submodels.object[["meta"]][["vars"]]))) %>% 
    drop_na(all_of(submodels.object[["meta"]][["force_variables"]]))
  SDATA<- mod.DATA%>% dplyr::select(any_of(submodels.object[["meta"]][["vars"]]))
  
  #adding missing cols
  missing_vars=submodels.object[["meta"]][["vars"]][submodels.object[["meta"]][["vars"]] %notin% names(SDATA)]
  
  for(i in missing_vars){
    SDATA[,i] <- NA
  }
  SDATA=SDATA %>% dplyr::select(any_of(submodels.object[["meta"]][["vars"]]))
  ###
  # tmp.dat<- as.data.frame(is.na(SDATA)*1)
  # tmp.pattern<- factor(apply(tmp.dat,1,function(z) paste(z,collapse="")))
  # tmp.info<- split(seq(nrow(SDATA)), tmp.pattern)
  # 
  # 
  # mp.levels<- levels(tmp.pattern)
  # mp.pattern<- do.call(rbind, lapply(as.list(mp.levels),function(ZZ) strsplit(ZZ,'')[[1]])) 		
  # mp.info<- data.frame(cbind(names(tmp.info), unlist(lapply(tmp.info, length))),
  #                      stringsAsFactors= FALSE)
  # rownames(mp.info) <- seq(nrow(mp.info))
  # colnames(mp.info) <- c('mp','n')
  ###
  unpack(missingness_pattern(SDATA))
  mp.info.object=submodels.object[["meta"]][["mp.info"]]  %>% dplyr::mutate(rn = row_number()) %>% filter(mp %in% mp.info$mp)
  
  pred.out=SDATA[0,]
  pred.out$fit=numeric(0)
  if(se.fit){
    pred.out$se.fit=numeric(0)
  }
  
  
  for(i in 1:nrow(mp.info.object)){
    newdata=SDATA[tmp.info[[mp.info.object$mp[i]]],]
    
    
    pred=predict(submodels.object[[mp.info.object$rn[i]]][["mod"]], newdata=newdata, se.fit=se.fit,...)
    if(se.fit){
      newdata$fit=pred$fit 
      newdata$se.fit=pred$se.fit
    }else{
      newdata$fit=pred.out
    }
    pred.out=pred.out %>% rbind(newdata)
  }
  if(!retain_lhs){
    pred.out =pred.out %>% dplyr::select(-any_of(mod.lhs))
  }
  
  return(pred.out)
}

submodel.print=function(submodels.object, long_wide=c("long", "wide")){
  out=list()
  f <- function(x =c("long", "wide")) {
    x <- match.arg(x)
    return(x)
  }
  out[["meta"]]=submodels.object[["meta"]]
  coefficients=tribble(~"pattern",~"var", ~"coef" )
  for(i in 1:(length(submodels.object)-1)){
    # cat(paste(i, "\n"))
    coefficients1=data.frame("pattern"=(submodels.object[[i]][["mod"]][["terms"]] %>% as.character())[3],
                             "var"=names(submodels.object[[i]][["mod"]][["coefficients"]]),
                             "coef"=submodels.object[[i]][["mod"]][["coefficients"]] )
    coefficients=rbind(coefficients, coefficients1)
    
  }
  long_wide=f(long_wide)
  if(long_wide=="long"){
    out[["coefficients"]]=coefficients
  }
  if(long_wide=="wide"){
    out[["coefficients"]]=coefficients %>% pivot_wider(names_from = "var", values_from="coef")
  }
  return(out)
}



model_breakdown=function(model){
  model=str_squish(model)
  mod.lhs <- strsplit(model, '~')[[1]][1] %>% str_squish()
  mod.rhs0 <- strsplit(model, '~')[[1]][2]
  mod.rhs.interaction0 <- strsplit(mod.rhs0,'\\+')[[1]]
  mod.rhs <- strsplit(mod.rhs0,'\\+|\\*')[[1]] %>% str_squish()
  mod.rhs <- str_squish(mod.rhs[!(mod.rhs%in%c('','+','~'))])
  
  #getting the interaction terms
  mod.rhs.interaction0=mod.rhs.interaction0[which(grepl("\\*", mod.rhs.interaction0))]%>% str_squish()
  mod.rhs.interaction2=str_split(mod.rhs.interaction0, "\\*")
  mod.rhs.interaction=c()
  if(length(mod.rhs.interaction2)>0){
    for(j in 1:length(mod.rhs.interaction2)){
      for(i in length(mod.rhs.interaction2[[j]]):2){
        mod.rhs.interaction3=t(combn(mod.rhs.interaction2[[j]],i)) %>% as.data.frame()
        mod.rhs.interaction4 <- apply( mod.rhs.interaction3 , 1 , paste , collapse = "*" )
        mod.rhs.interaction=c(mod.rhs.interaction, mod.rhs.interaction4)
        
      }
    }
  }
  return(list("mod.rhs"=mod.rhs,
              "mod.lhs"=mod.lhs,
              "mod.rhs.interaction"=mod.rhs.interaction))
}

# actual=test$exac_modsev_n
# predicted=test$fit
auc=function(data, actual, predicted, boot=F,...){
  
  
  x=cbind.data.frame(data[actual], data[predicted])
  names(x)=c("actual", "predicted")
  y=cross_join(x,x) %>% filter(predicted.x<predicted.y, actual.x!=actual.y) %>% 
    mutate(correct=actual.x<actual.y)
  
  if(boot)
  {
    b=boot::boot(x, statistic=auc_boot, R=1000, actual="actual", predicted="predicted")
    b1=boot::boot.ci(b, type="norm")
    b2=b1$normal
    return(data.frame("t"=mean(y$correct),
                      "lower"=b2[2],
                      "upper"=b2[3]))
  }
  if(!boot){
    return(mean(y$correct))
  }
}
# auc(test, "exac_modsev_n", "fit", boot=T )

auc_boot=function(data, indices, actual, predicted)
{
  d=data[indices,]
  return(auc(d, actual,predicted, boot=F))
}
# b=boot::boot(test, statistic=auc_boot, R=1000, actual="exac_modsev_n", predicted="fit")
# 
# b1=boot::boot.ci(b)
# b2=b1$normal



unpack=function(list)
{
  for(i in names(list))
  {
    
    assign(i, list[[i]], envir = .GlobalEnv)
    
  }
}

missingness_pattern=function(SDATA){
  tmp.dat      <- as.data.frame(is.na(SDATA)*1)
  tmp.pattern  <- factor(apply(tmp.dat,1,function(z) paste(z,collapse="")))
  tmp.info     <- split(seq(nrow(SDATA)), tmp.pattern)
  mp.levels    <- levels(tmp.pattern)
  mp.pattern   <- do.call(rbind, lapply(as.list(mp.levels),function(ZZ) strsplit(ZZ,'')[[1]])) 		
  mp.info     <- data.frame(cbind(names(tmp.info), unlist(lapply(tmp.info, length))),
                            stringsAsFactors= FALSE)
  rownames(mp.info) <- seq(nrow(mp.info))
  colnames(mp.info) <- c('mp','n')
  
  return(list("tmp.dat"=tmp.dat, "tmp.pattern"=tmp.pattern, "tmp.info"=tmp.info, "mp.levels"=mp.levels, "mp.pattern"=mp.pattern, "mp.info"=mp.info))
}
